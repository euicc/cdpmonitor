# to keep the global variable
import json
import os

with open('config.json', 'r') as f:
    config = json.load(f)

